from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
import struct
from pathlib import Path

EXPECTED_MODEL_SHA256 = "9a504fb699d335836737a54fbdd839f3c9d2e3d48c0c2fc3dec2ff300ccc4300"
EXPECTED_MAGIC = b"TAIDTF1\0"
EXPECTED_ENTRY_COUNT = 80000
EXPECTED_MAX_CODE_POINTS = 192
DEFAULT_TOLERANCE = 1e-5


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def detect_layout(root: Path) -> dict[str, Path]:
    handoff_model = root / "model" / "tfidf_opening_192_plus_nlpcc.taid"
    project_model = root / "artifacts" / "mobile" / "tfidf_opening_192_plus_nlpcc.taid"
    if handoff_model.exists():
        return {"model": handoff_model, "reference": root / "reference" / "taidtf1.py", "golden": root / "tests" / "golden_vectors.json", "layout": Path("handoff")}
    if project_model.exists():
        return {"model": project_model, "reference": root / "src" / "inference" / "taidtf1.py", "golden": root / "tests" / "golden_vectors.json", "layout": Path("project")}
    raise FileNotFoundError("could not find model in handoff layout or project layout")


def load_reference(reference_path: Path):
    spec = importlib.util.spec_from_file_location("taidtf1_reference", reference_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"could not import reference runtime from {reference_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.TaidTfidfModel


def inspect_header(model_path: Path) -> dict[str, object]:
    data = model_path.read_bytes()
    if len(data) < 20:
        raise ValueError("model file is shorter than the 20-byte TAIDTF1 header")
    magic, entry_count, max_code_points, intercept = struct.unpack_from("<8sIIf", data, 0)
    return {"magic": magic.decode("ascii", errors="replace"), "entry_count": int(entry_count), "max_code_points": int(max_code_points), "intercept": float(intercept)}


def main() -> None:
    parser = argparse.ArgumentParser(description="Verify the Expo TAIDTF1 handoff package.")
    parser.add_argument("--root", type=Path, default=Path.cwd(), help="Project root or unzipped handoff root")
    parser.add_argument("--tolerance", type=float, default=DEFAULT_TOLERANCE)
    args = parser.parse_args()

    root = args.root.resolve()
    layout = detect_layout(root)
    model_path = layout["model"]
    reference_path = layout["reference"]
    golden_path = layout["golden"]

    if not reference_path.exists():
        raise FileNotFoundError(f"missing reference runtime: {reference_path}")
    if not golden_path.exists():
        raise FileNotFoundError(f"missing golden vectors: {golden_path}")

    model_sha = sha256_file(model_path)
    if model_sha != EXPECTED_MODEL_SHA256:
        raise AssertionError(f"model SHA256 mismatch: {model_sha} != {EXPECTED_MODEL_SHA256}")

    header = inspect_header(model_path)
    if header["magic"].encode("ascii") != EXPECTED_MAGIC:
        raise AssertionError(f"model magic mismatch: {header['magic']!r}")
    if header["entry_count"] != EXPECTED_ENTRY_COUNT:
        raise AssertionError(f"entry_count mismatch: {header['entry_count']}")
    if header["max_code_points"] != EXPECTED_MAX_CODE_POINTS:
        raise AssertionError(f"max_code_points mismatch: {header['max_code_points']}")

    TaidTfidfModel = load_reference(reference_path)
    model = TaidTfidfModel(model_path)
    golden = json.loads(golden_path.read_text(encoding="utf-8"))
    vectors = golden.get("vectors", [])
    if not vectors:
        raise AssertionError("golden_vectors.json contains no vectors")

    max_abs_error = 0.0
    failures = []
    for row in vectors:
        actual = float(model.predict_proba_one(row.get("text", "")))
        expected = float(row["expected_probability"])
        if not math.isfinite(actual):
            failures.append({"id": row.get("id"), "error": "non-finite probability", "actual": actual})
            continue
        err = abs(actual - expected)
        max_abs_error = max(max_abs_error, err)
        if err > args.tolerance:
            failures.append({"id": row.get("id"), "expected": expected, "actual": actual, "abs_error": err})

    result = {"validation_pass": not failures, "layout": str(layout["layout"]), "root": str(root), "model": str(model_path), "model_sha256": model_sha, "header": header, "golden_vector_count": len(vectors), "max_abs_probability_error": max_abs_error, "tolerance": args.tolerance, "failures": failures}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
