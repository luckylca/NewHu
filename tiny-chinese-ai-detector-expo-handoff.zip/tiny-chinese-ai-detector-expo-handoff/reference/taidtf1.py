from __future__ import annotations

"""Pure-Python reference runtime for the TAIDTF1 Chinese AI-like text detector.

This file intentionally uses only the Python standard library so that an Expo / React
Native implementer can compare their TypeScript port against a very small, readable
reference implementation. It is not the fastest possible implementation; it is the
semantic contract.
"""

import json
import math
import re
import struct
from collections import Counter
from pathlib import Path
from typing import Iterable

MAGIC = b"TAIDTF1\0"
HEADER_STRUCT = struct.Struct("<8sIIf")
ENTRY_LENGTH_STRUCT = struct.Struct("<H")
ENTRY_VALUE_STRUCT = struct.Struct("<ff")


class TaidTfidfModel:
    """TAIDTF1 character TF-IDF + logistic-regression inference runtime."""

    def __init__(self, model_path: str | Path):
        self.path = Path(model_path)
        self.entry_count: int
        self.max_code_points: int
        self.intercept: float
        self.features: dict[str, tuple[float, float]] = {}
        self._load()

    def _load(self) -> None:
        data = self.path.read_bytes()
        if len(data) < HEADER_STRUCT.size:
            raise ValueError("TAIDTF1 file is too small to contain a header")

        magic, entry_count, max_code_points, intercept = HEADER_STRUCT.unpack_from(data, 0)
        if magic != MAGIC:
            raise ValueError(f"invalid TAIDTF1 magic: {magic!r}")

        offset = HEADER_STRUCT.size
        features: dict[str, tuple[float, float]] = {}
        for index in range(int(entry_count)):
            if offset + ENTRY_LENGTH_STRUCT.size > len(data):
                raise ValueError(f"unexpected end of file while reading token length at entry {index}")
            (token_bytes_len,) = ENTRY_LENGTH_STRUCT.unpack_from(data, offset)
            offset += ENTRY_LENGTH_STRUCT.size

            value_end = offset + int(token_bytes_len) + ENTRY_VALUE_STRUCT.size
            if value_end > len(data):
                raise ValueError(f"unexpected end of file while reading entry {index}")

            token_raw = data[offset : offset + int(token_bytes_len)]
            offset += int(token_bytes_len)
            token = token_raw.decode("utf-8")
            idf, coefficient = ENTRY_VALUE_STRUCT.unpack_from(data, offset)
            offset += ENTRY_VALUE_STRUCT.size
            features[token] = (float(idf), float(coefficient))

        if offset != len(data):
            raise ValueError(f"TAIDTF1 parser stopped at byte {offset}, but file has {len(data)} bytes")

        self.entry_count = int(entry_count)
        self.max_code_points = int(max_code_points)
        self.intercept = float(intercept)
        self.features = features

    @staticmethod
    def sigmoid(logit: float) -> float:
        if logit >= 0:
            z = math.exp(-logit)
            return 1.0 / (1.0 + z)
        z = math.exp(logit)
        return z / (1.0 + z)

    def preprocess(self, text: object) -> str:
        if text is None:
            s = ""
        else:
            s = str(text)
        s = "".join(ch for _, ch in zip(range(self.max_code_points), s))
        s = s.lower()
        s = re.sub(r"\s\s+", " ", s)
        return s

    @staticmethod
    def iter_char_ngrams(chars: list[str], min_n: int = 2, max_n: int = 5) -> Iterable[str]:
        length = len(chars)
        for n in range(min_n, max_n + 1):
            if length < n:
                continue
            for start in range(0, length - n + 1):
                yield "".join(chars[start : start + n])

    def decision_function(self, text: object) -> float:
        s = self.preprocess(text)
        chars = list(s)
        counts: Counter[str] = Counter()
        for gram in self.iter_char_ngrams(chars):
            if gram in self.features:
                counts[gram] += 1

        if not counts:
            return self.intercept

        weighted: list[tuple[float, float]] = []
        norm_sq = 0.0
        for gram, count in counts.items():
            idf, coefficient = self.features[gram]
            tf = 1.0 + math.log(float(count))
            value = tf * idf
            norm_sq += value * value
            weighted.append((value, coefficient))

        if norm_sq <= 0.0:
            return self.intercept
        norm = math.sqrt(norm_sq)
        return self.intercept + sum((value / norm) * coefficient for value, coefficient in weighted)

    def predict_proba_one(self, text: object) -> float:
        return self.sigmoid(self.decision_function(text))

    def predict(self, text: object, threshold: float = 0.5) -> int:
        return int(self.predict_proba_one(text) >= threshold)


def _main() -> None:
    import argparse

    parser = argparse.ArgumentParser(description="Run one TAIDTF1 reference prediction.")
    parser.add_argument("model", type=Path)
    parser.add_argument("text", nargs="?", default="")
    parser.add_argument("--threshold", type=float, default=0.5)
    args = parser.parse_args()

    model = TaidTfidfModel(args.model)
    logit = model.decision_function(args.text)
    probability = model.sigmoid(logit)
    print(json.dumps({
        "probability": probability,
        "logit": logit,
        "label_at_threshold": int(probability >= args.threshold),
        "threshold": args.threshold,
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    _main()
