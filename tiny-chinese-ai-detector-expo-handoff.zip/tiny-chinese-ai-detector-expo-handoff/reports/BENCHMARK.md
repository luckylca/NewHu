# Benchmark

All internal numbers use the leakage-safe C-ReD + HC3 split unless explicitly marked external. The fixed internal test set contains 14,883 samples; group leakage and exact-text cross-split leakage are both zero. External NLPCC test sets are never used for threshold or model selection.

## Main internal test

| Model | Input | Test accuracy | Macro F1 | AUROC | Human FPR | Deployable resource |
|---|---:|---:|---:|---:|---:|---:|
| Char TF-IDF + LR | 64 chars | 0.95572 | — | 0.99101 | 5.64% | 1.46 MB joblib |
| Char TF-IDF + LR | 128 chars | 0.97615 | — | 0.99675 | 3.27% | 1.50 MB joblib |
| Char TF-IDF + LR | 192 chars | 0.98401 | — | 0.99825 | 2.27% | 1.52 MB joblib |
| Char TF-IDF + LR | 256 chars | 0.98596 | — | 0.99861 | 2.03% | 1.53 MB joblib |
| **TF-IDF 192 + NLPCC-2025 train augmentation** | **192 chars** | **0.98314** | **0.97587** | **0.99815** | **2.00%** | **1.465 MB TAIDTF1 mobile pack** |
| Char-CNN safe INT8 | 192 chars | 0.97440 | 0.96357 | 0.99615 | 3.15% | 1.294 MB incl. vocab |
| Char-CNN + NLPCC train safe INT8 | 192 chars | 0.97070 | 0.95943 | 0.99598 | 2.94% | ~1.294 MB incl. vocab |
| Student-S hard label | 192 chars | 0.94752 | 0.92771 | 0.98962 | 4.34% | ~0.93 MB after dynamic INT8 architecture export |
| Student-S distilled T=4, alpha=0.5 INT8 | 192 chars | 0.96096 | 0.94195 | 0.98948 | 12.31% @0.5 | **0.926 MB incl. vocab** |
| Student-L dynamic INT8 | 256 chars | 0.96009 | 0.94404 | 0.99304 | 4.21% | 2.208 MB incl. vocab |
| MacBERT teacher | 192 chars | 0.98797 | 0.98225 | 0.99979 | 5.18% | ~409 MB weights; teacher only |

The first TF-IDF length sweep predates addition of `macro_f1` to the common metric function, so those historical entries retain `—` rather than being retroactively reconstructed.

## Title ablation

| Input | Accuracy | Macro F1 | AUROC | Human FPR |
|---|---:|---:|---:|---:|
| opening 192 | 0.98401 | — | 0.99825 | 2.27% |
| title + opening 192 | 0.98334 | 0.97610 | 0.99827 | 2.27% |
| title only | 0.77935 | 0.71436 | 0.75617 | 31.78% |

Title does not materially improve the 192-character detector and cannot be required because HC3 does not provide titles.

## External OOD: NLPCC-2025 DetectRL-ZH

The NLPCC-2025 test uses unseen STORAL creative-writing data, unseen DeepSeek-V3 generation, attacks, and controlled lengths. The released NLPCC train split can be used as an augmentation source without touching its test split. After exact-text protection, 32,155 of 32,400 released train rows were safely added to the training partition only.

| Frozen model | Three-scenario mean macro-F1 | Attack-all macro-F1 | Varying-length macro-F1 |
|---|---:|---:|---:|
| TF-IDF 192, original corpus | 0.71651 | 0.72346 | 0.72735 |
| **TF-IDF 192 + NLPCC train** | **0.76202** | **0.77014** | **0.76821** |
| Char-CNN safe INT8, original corpus | 0.69904 | 0.69748 | 0.70780 |
| Char-CNN safe INT8 + NLPCC train | 0.72231 | 0.73056 | 0.72640 |
| Student-S hard label | 0.63129 | 0.63084 | 0.64201 |
| Student-L dynamic INT8 | 0.66122 | 0.66294 | 0.67046 |
| **Student-S distilled T=4, alpha=0.5 dynamic INT8** | **0.72869** | **0.72400** | **0.74321** |
| MacBERT teacher | **0.82560** | 0.83114 | 0.82882 |

The strongest mobile-size OOD score is therefore the augmented TF-IDF model, not the deepest tiny neural network. Data/generator/domain coverage is a larger lever than simply increasing student parameter count.

## Knowledge distillation result

MacBERT teacher logits were generated for all 148,818 unified records. Distillation is useful specifically for OOD transfer:

- hard-label Student-S: NLPCC-2025 mean macro-F1 **0.63129**;
- distilled Student-S (`T=4`, `alpha=0.5`): **0.72821 FP32 / 0.72869 INT8**;
- internal AUROC remains about 0.9895, so the gain is not an in-domain metric artifact;
- the teacher's score bias is also transferred, making threshold calibration mandatory.

A more hard-label-heavy candidate (`T=2`, `alpha=0.8`) improved default in-domain FPR but reduced frozen external macro-F1 to 0.68862. It is therefore not the selected distillation candidate.

## Mobile artifacts

| Candidate | Model/resource bytes | Desktop CPU evidence | Internal AUROC | NLPCC-2025 mean macro-F1 | Status |
|---|---:|---:|---:|---:|---|
| **TF-IDF TAIDTF1 + NLPCC train** | **1,464,732 B** | Python reference ~0.21 ms/sample | **0.99815** | **0.76202** | **preferred default candidate** |
| Distilled Student-S dynamic INT8 + vocab | **925,542 B** | ORT ~0.83 ms/sample | 0.98948 | 0.72869 | semantic/OOD secondary candidate |
| Char-CNN safe QDQ INT8 + vocab | 1,294,298 B | ORT ~0.109 ms/sample | 0.99615 | 0.69904 | fastest ONNX candidate |
| Char-CNN + NLPCC train safe QDQ INT8 | ~1.294 MB | executable | 0.99598 | 0.72231 | augmented ONNX candidate |
| Student-L dynamic INT8 + vocab | 2,207,669 B | ORT ~3.64 ms/sample | 0.99304 | 0.66122 | rejected for poorer OOD |

The custom TF-IDF mobile pack is not merely a serialized sklearn object. `TAIDTF1` stores 80,000 UTF-8 n-grams, IDF values, logistic weights, the intercept, and max input length. A standalone reference implementation reproduces sklearn on all 11,000 NLPCC-2025 external texts with maximum absolute probability error **5.90e-08**, mean error **8.33e-09**, and 100% decision agreement at threshold 0.5.

## Operating points and threshold transport

For augmented TF-IDF, validation-selected internal operating points transfer reasonably on the fixed internal test:

| Validation Human-FPR budget | Threshold | Test Human FPR | Test AI recall |
|---|---:|---:|---:|
| <=1% | 0.66485 | 1.00% | 96.91% |
| <=2% | 0.51375 | 1.85% | 98.36% |
| <=5% | 0.29175 | 4.85% | 99.32% |

On NLPCC-2025, the 1%-budget threshold produces about 1.53% Human FPR but lowers the three-scenario macro-F1 from 0.76202 to 0.70507. The product should therefore expose a balanced/default score and an optional conservative threshold rather than treating one threshold as universally calibrated.

The distilled Student-S is more distribution-sensitive. Its internal <=5% threshold (`0.99964866`) gives 4.09% test Human FPR and 93.66% recall, but on NLPCC-2025 it lowers external macro-F1 from 0.72869 to 0.64315. This is strong evidence that probability calibration and threshold transfer are separate from ranking quality.

## NLPCC-2026 LLM-refined stress test

Phase-2 contains balanced HWT/LGT/HLT (384 each). Treating LGT and HLT as AI-like:

| Frozen model | Binary AUROC | HWT FPR @0.5 | LGT positive | HLT positive |
|---|---:|---:|---:|---:|
| TF-IDF 192 original | ~0.839 | 5.47% | 89.84% | 26.04% |
| **TF-IDF 192 + NLPCC train** | **0.83936** | **5.47%** | **88.54%** | **30.47%** |
| Char-CNN + NLPCC train INT8 | 0.82815 | 9.64% | 88.80% | 35.68% |
| Distilled Student-S INT8 | 0.79128 | 32.81% | 92.19% | **54.95%** |
| MacBERT teacher | **0.90717** | 10.94% | **99.48%** | 49.74% |

A dedicated three-class HWT/LGT/HLT experiment was also run. It reaches about 0.60 internal macro-F1 but only **0.2375 external macro-F1** on phase-2 and collapses heavily toward the Refined class. Therefore the current project does **not** claim reliable Human / fully-AI / AI-refined three-way classification. HLT remains a research target; production output should be an AI-like risk score with explicit uncertainty.

## Generalization warning

Same-dataset leave-one-generator-out can look deceptively strong: most C-ReD modern generators score AUROC 0.993–0.9998 when held out. Holding out HC3 `ChatGPT` together with its source/domain distribution drops AUROC to 0.8267 and macro-F1 to 0.4722. Cross-domain holdouts are also much harder; for example paper AUROC is 0.8933 with 13.86% Human FPR while film review reaches 0.9992 AUROC. Generator robustness must therefore be reported separately from cross-source/domain robustness.

