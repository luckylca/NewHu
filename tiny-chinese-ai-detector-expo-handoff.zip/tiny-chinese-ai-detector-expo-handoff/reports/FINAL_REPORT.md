﻿# Final Report

## Executive conclusion

The research target is feasible, but the winning mobile model is **not** the Tiny Transformer. The best overall size / internal accuracy / Human-FPR / external-generalization trade-off is the **192-code-point character TF-IDF + Logistic Regression model augmented only with the leakage-protected NLPCC-2025 training split**.

The selected Expo release artifact is:

- `artifacts/mobile/tfidf_opening_192_plus_nlpcc.taid`
- custom format: `TAIDTF1`
- size: `1,464,732` bytes (~1.40 MiB)
- SHA256: `9a504fb699d335836737a54fbdd839f3c9d2e3d48c0c2fc3dec2ff300ccc4300`
- vocabulary: 80,000 character 2-5 grams
- maximum input: first 192 Unicode code points of body/opening
- no ONNX Runtime required

A fresh export was byte-for-byte identical to the release file. Across all 14,883 internal test samples and all 11,000 NLPCC-2025 external samples, the standalone `TAIDTF1` implementation had 100% decision agreement with the sklearn source at threshold 0.5; maximum absolute probability errors were approximately `7.7e-8` and `5.9e-8`, respectively.

## Dataset and leakage control

The primary unified dataset uses C-ReD and HC3 Chinese with group-aware splitting. Related prompt/source groups are kept together and exact-text cross-split leakage is checked. NLPCC-2025 train augmentation is added to the training partition only after exact-text protection against validation/test rows. NLPCC external tests are not used to tune the model or threshold.

NLPCC-2026 refined-text experiments use source/base-article grouping rather than generator-specific IDs because the latter can place rewrites of the same source article into different splits. Exact contradictory HWT/HLT strings were audited and isolated for a transparent cleaning ablation.

## Answers to the required research questions

### 1. Is short-opening Chinese AI-text detection feasible?

Yes in-domain. Character TF-IDF reaches AUROC `0.9910` at 64 characters and `0.99825` at 192 characters. However, external-domain performance is materially lower, so the result is a useful detector rather than a universal authorship oracle.

### 2. 64 / 128 / 192 / 256 input trade-off

Internal test AUROC / Human FPR:

- 64: `0.99101` / `5.64%`
- 128: `0.99675` / `3.27%`
- 192: `0.99825` / `2.27%`
- 256: `0.99861` / `2.03%`

192 is the chosen price/performance point. The 256-character gain is small.

### 3. Does title help?

No material benefit at the chosen operating point. Title + opening192 has almost the same AUROC as opening192, while title-only is much weaker. The final model is opening-only and ignores title.

### 4. What can a ~1 MB model do?

The distilled Student-S dynamic INT8 resource is about `0.926 MB` including vocab. It reaches internal AUROC `0.98948` and NLPCC-2025 mean macro-F1 `0.72869`. This proves sub-1MB semantic neural inference is practical, but it is not the overall winner.

### 5. What can a ~2 MB model do?

Student-L dynamic INT8 is about `2.21 MB` including vocab, internal AUROC `0.99304`, but NLPCC-2025 mean macro-F1 only `0.66122`. Extra Tiny Transformer capacity did not solve OOD generalization.

### 6. Best model under the 5 MB limit

The selected TF-IDF `TAIDTF1` artifact at ~1.40 MiB. It has internal AUROC `0.99815` after NLPCC-2025 train augmentation and NLPCC-2025 official three-scenario mean macro-F1 `0.76202`.

### 7. Char-CNN vs Tiny Transformer

For this task and data, neither beat the final TF-IDF model. Char-CNN is a useful fast ONNX reference (safe INT8 ~1.29 MB including vocab, internal AUROC `0.99615`), while the distilled Student-S is the better compact semantic/OOD neural candidate. The simpler TF-IDF model remains the preferred product default.

### 8. Did knowledge distillation help?

Yes, strongly for OOD transfer. Student-S NLPCC-2025 mean macro-F1 improved from `0.63129` hard-label to about `0.72869` after T=4, alpha=0.5 distillation and INT8. Distillation also transfers teacher score bias, so it does not solve calibration automatically.

### 9. What is the INT8 cost?

Quantization is not the blocker. Aggressively quantizing the Char-CNN embedding caused severe drift and was rejected; selective QDQ preserving the embedding in FP32 retained accuracy. Student dynamic INT8 also retained external quality closely. Multiple complete neural resources are below 5 MB.

### 10. Unseen-generator robustness

Within C-ReD, most leave-one-generator-out cases remain very strong. The difficult counterexample is HC3 ChatGPT held out together with its source/domain distribution: AUROC falls to about `0.8267` and macro-F1 to `0.4722`. Generator robustness and source/domain robustness cannot be conflated.

### 11. Cross-domain robustness

It varies substantially. Examples include C-ReD paper AUROC about `0.8933` with Human FPR `13.86%`, while film review reaches AUROC about `0.9992`. This is the main reason the product must expose uncertainty and avoid absolute claims.

### 12. Is Human false-positive risk acceptable?

On the fixed internal test, yes at versioned operating points. For the selected model, validation-derived thresholds provide approximately:

- threshold `0.6648456937`: test Human FPR ~`1.00%`, AI recall ~`96.91%`;
- threshold `0.5137511455`: test Human FPR ~`1.85%`, AI recall ~`98.36%`;
- threshold `0.2917528562`: test Human FPR ~`4.85%`, AI recall ~`99.32%`.

But external/domain-shift FPR can be much higher, so these are not universal guarantees.

### 13. Is the final model suitable for Expo?

Yes from the model/runtime perspective. The selected model is a small static binary plus straightforward TF-IDF/logistic arithmetic, so it can be implemented directly in TypeScript/JavaScript without ONNX Runtime. The release handoff includes exact binary/preprocessing semantics and golden-vector acceptance tests. Device-specific Expo load time and JS memory still need to be profiled in the target app after integration.

## NLPCC-2025 external gate

Selected model (`TF-IDF 192 + NLPCC train`):

- normal macro-F1: `0.74770`
- all attacks macro-F1: `0.77014`
- varying-length macro-F1: `0.76821`
- official three-scenario mean macro-F1: `0.76202`

The external gap from the internal benchmark is real and retained in the report rather than tuned away.

## NLPCC-2026 refined-text warning

For HWT vs LGT-or-HLT, the selected model reaches binary AUROC about `0.83936`. At threshold 0.5 it flags about `88.54%` of fully generated LGT but only `30.47%` of HLT refined text. A dedicated HWT/LGT/HLT three-class experiment failed to generalize adequately. Therefore the production contract remains a single AI-like score and does not claim reliable three-way authorship classification.

## Calibration

For the selected model, Platt/isotonic calibration improves calibration metrics but changes the 0.5 operating point and Human FPR. The release therefore ships the raw logistic score plus separately versioned thresholds. Calibration and threshold selection are treated as distinct concerns.

## Release validation

`reports/RELEASE_VALIDATION_EXPO.json` records the final release check. The release passes:

- project tests: `14 passed`;
- fresh mobile export is byte-identical to the frozen artifact;
- feature count `80000`, max input `192`;
- internal 14,883-sample sklearn/mobile decision agreement: `100%`;
- NLPCC-2025 11,000-sample sklearn/mobile decision agreement: `100%`;
- all compared probability errors are far below `1e-6`.

## Product-language requirement

The UI must describe the output as an **AI-like score / AI-writing-feature risk score**. Do not describe a score such as 0.91 as “91% of this article was written by AI.” The detector measures statistical similarity to the training distribution and can be wrong under domain, generator, editing, or style shift.

## Expo handoff

See `docs/EXPO_MIGRATION.md` and `docs/TAIDTF1_FORMAT.md`. The self-contained ZIP under `artifacts/final/` is the intended handoff to a new AI or implementation engineer.

