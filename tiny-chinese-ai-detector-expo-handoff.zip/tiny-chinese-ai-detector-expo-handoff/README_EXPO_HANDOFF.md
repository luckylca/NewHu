# Tiny Chinese AI Detector — Expo Handoff

This package is the self-contained handoff for migrating the selected Chinese AI-like text detector into an Expo / React Native app.

## What is inside

- `model/tfidf_opening_192_plus_nlpcc.taid` — final binary model, custom `TAIDTF1` format.
- `reference/taidtf1.py` — pure-Python reference parser and inference implementation.
- `tests/golden_vectors.json` — acceptance vectors for a TypeScript/JavaScript port.
- `scripts/verify_expo_handoff.py` — verifies model SHA256, TAIDTF1 header, and golden-vector predictions.
- `docs/EXPO_MIGRATION.md` — exact Expo / React Native implementation contract.
- `docs/TAIDTF1_FORMAT.md` — binary format and inference math.
- `reports/FINAL_REPORT.md` — final research conclusion and model selection evidence.
- `reports/RELEASE_VALIDATION_EXPO.json` — frozen release validation results.
- `reports/BENCHMARK.md` — benchmark summary retained for context.
- `CHECKSUMS.sha256` and `handoff_manifest.json` — integrity metadata.

## Selected model

- Architecture: character TF-IDF + Logistic Regression.
- Input: first 192 Unicode code points of the body/opening text.
- Title: not used.
- Model size: 1,464,732 bytes, approximately 1.40 MiB.
- SHA256: `9a504fb699d335836737a54fbdd839f3c9d2e3d48c0c2fc3dec2ff300ccc4300`.
- Runtime dependency: no ONNX Runtime required; implement directly in TypeScript/JavaScript.

## Verification

From the unzipped package root:

```bash
python scripts/verify_expo_handoff.py --root .
```

The script should print `"validation_pass": true`.

## Expo implementation target

The new AI or implementation engineer should:

1. Add `.taid` to Expo/Metro asset handling without changing the bytes.
2. Load and parse the binary once at app startup or first use.
3. Reproduce the preprocessing exactly: null to empty string, truncate by Unicode code points, lowercase, collapse Python-style `\s\s+` whitespace runs to one ASCII space, and do no other normalization.
4. Generate overlapping character 2-5 grams by Unicode code points.
5. Compute sublinear-TF, IDF, L2 normalization, logistic logit, and sigmoid exactly as described in `docs/TAIDTF1_FORMAT.md`.
6. Run every vector in `tests/golden_vectors.json`; absolute probability error must be `<= 1e-5`.
7. Display the output as an AI-like score / AI-writing-feature risk score, not as proof of authorship or a percentage of text written by AI.

## Product wording constraint

Do not say “91% of this article was written by AI.” The score is a statistical AI-like risk/likeness score and can be wrong under domain shift, generator shift, editing, or unusual style.
