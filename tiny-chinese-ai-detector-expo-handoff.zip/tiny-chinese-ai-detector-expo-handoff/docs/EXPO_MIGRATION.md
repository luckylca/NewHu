# Expo / React Native Migration Contract

## 1. What must be shipped

Use the selected `TAIDTF1` model:

- file: `tfidf_opening_192_plus_nlpcc.taid`
- bytes: `1,464,732`
- SHA256: `9a504fb699d335836737a54fbdd839f3c9d2e3d48c0c2fc3dec2ff300ccc4300`
- format magic: `TAIDTF1\0`
- vocabulary entries: `80,000`
- maximum input: first `192` Unicode code points of the body/opening
- title: **not used by the selected model**

This release does not require ONNX Runtime. The Expo implementation only needs to load one binary asset, parse it, reproduce the preprocessing below, compute TF-IDF + logistic regression, and return a score in `[0, 1]`.

## 2. Exact inference contract

Do these operations in this order. Changing the order changes predictions.

1. Convert missing/null input to the empty string.
2. Take the first **192 Unicode code points** of the body text. Do not truncate by UTF-16 code units and do not truncate UTF-8 bytes.
3. Lowercase using Unicode-aware lowercase semantics.
4. Replace every run of **two or more whitespace characters** matching the source Python regex `\s\s+` with one ASCII space (`U+0020`). A single whitespace character is retained unchanged.
5. Do **not** apply NFC, NFKC, punctuation removal, Chinese word segmentation, stemming, stop-word removal, HTML stripping, or any other normalization.
6. Enumerate overlapping character n-grams of lengths `2, 3, 4, 5` over Unicode code points.
7. Count only n-grams present in the 80,000-entry model vocabulary.
8. For each matched n-gram with count `c`, compute `tf = 1 + ln(c)`.
9. Compute the unnormalized TF-IDF value `v = tf * idf`.
10. Compute `norm = sqrt(sum(v^2))` across all matched features.
11. If no feature matches, the logit is exactly the stored intercept.
12. Otherwise compute `logit = intercept + sum((v / norm) * coefficient)`.
13. Convert logit to probability with a numerically stable sigmoid.

The returned value is the **AI-like score**. It is not a probability that a specific percentage of the text was written by AI and must not be presented as proof of authorship.

## 3. JavaScript / TypeScript details that matter

### Unicode truncation

JavaScript `string.slice(0, 192)` counts UTF-16 code units and is therefore not equivalent for supplementary characters such as emoji. Use code-point iteration, for example `Array.from(text).slice(0, 192).join("")`, or an equivalent implementation.

The n-gram loop must also operate on Unicode code points, not raw UTF-16 indices.

### Binary parsing

Read the model as bytes and use little-endian integer/float decoding. `DataView` is suitable. UTF-8 token bytes must be decoded exactly; `TextDecoder("utf-8")` is suitable where available.

### Asset loading

The `.taid` file is a static application asset. The exact Expo SDK APIs may change, so the integrating agent should use the asset/file APIs appropriate to the target Expo SDK and ensure Metro treats `.taid` as an asset extension (or copy/rename it as a binary asset without changing its bytes).

Never parse the model on every prediction. Load it once and keep the parsed model in a singleton/service.

### Memory representation

A simple implementation can store `Map<string, number>` from n-gram to feature index and keep IDF and coefficient values in `Float32Array`s. Avoid allocating one JavaScript object per feature if memory is important. Only a few hundred n-gram lookups are required for a 192-code-point input, so inference itself is small; model-map memory should be profiled on target devices.

## 4. Thresholds

The model file stores the raw logistic model only; no Platt/isotonic post-calibrator is bundled. This is intentional.

Validation-selected operating points for this exact model are:

| Mode | Threshold | Internal test Human FPR | Internal AI recall |
|---|---:|---:|---:|
| Conservative | `0.6648456937028345` | ~`1.00%` | ~`96.91%` |
| Balanced-low-FP | `0.5137511455289535` | ~`1.85%` | ~`98.36%` |
| Permissive | `0.29175285624640523` | ~`4.85%` | ~`99.32%` |
| Raw/default research threshold | `0.5` | ~`2.00%` | ~`98.40%` |

Do not silently change thresholds. Version the chosen threshold together with the model SHA256.

The default UI should expose the continuous score. Any categorical label is only a thresholded interpretation.

## 5. Required port acceptance tests

The Expo port is accepted only if all of these pass:

1. SHA256 of the bundled model equals `9a504fb699d335836737a54fbdd839f3c9d2e3d48c0c2fc3dec2ff300ccc4300` before any rename/copy transformation.
2. Header parses as `TAIDTF1\0`, feature count `80000`, max code points `192`.
3. Every `tests/golden_vectors.json` vector matches the expected probability with absolute error `<= 1e-5`.
4. Empty input and one-code-point input return a finite score.
5. Emoji/supplementary characters do not get split by truncation or n-gram generation.
6. Runs of whitespace reproduce the golden vectors.
7. Repeated calls are deterministic.
8. The model is loaded once rather than reparsed for every call.

If the golden vectors do not match, do not compensate by changing thresholds. Fix preprocessing or binary parsing first.

## 6. Known limitations that the product must preserve

- Strong internal performance does not mean universal detection.
- NLPCC-2025 external performance is materially lower than in-domain performance.
- Cross-domain shift can raise Human false positives substantially; `paper` and some HC3 domains are harder than the in-domain test.
- LLM-refined/polished text (HLT) remains difficult. The selected binary model detects fully generated text much better than lightly AI-refined text.
- The project does **not** claim reliable three-way `Human / fully AI / AI-refined` classification.
- The score should be described as an AI-like statistical risk/likeness score.

## 7. What the next AI should implement in the Expo app

1. Add the `.taid` file as an app asset without changing its bytes.
2. Implement a typed `TaidTfidfModel` loader for the format in `TAIDTF1_FORMAT.md`.
3. Implement the exact preprocessing and inference contract above.
4. Add a reusable service such as `AiTextDetector.predict(text): Promise<number>` or synchronous equivalent after model initialization.
5. Add unit tests generated from `golden_vectors.json`.
6. Display the raw score and apply only an explicitly selected, versioned threshold.
7. Profile cold load, warm prediction time, and JS/native memory on representative Expo targets.
8. Keep the model SHA256 and threshold in app metadata/logging so bug reports can identify the exact detector version.

The ZIP handoff intentionally does not contain an Android-specific runtime. The target is Expo / React Native and the model is simple enough to implement directly in TypeScript/JavaScript.
