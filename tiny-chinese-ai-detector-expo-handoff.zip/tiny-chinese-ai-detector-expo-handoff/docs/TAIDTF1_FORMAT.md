# TAIDTF1 Binary Format

`TAIDTF1` is a compact binary representation of one character TF-IDF vectorizer plus one binary logistic-regression classifier.

All multibyte numeric fields are **little-endian**.

## Header

| Offset | Size | Type | Meaning |
|---:|---:|---|---|
| 0 | 8 | bytes | ASCII magic `TAIDTF1` followed by `0x00` |
| 8 | 4 | uint32 | vocabulary/entry count |
| 12 | 4 | uint32 | maximum input Unicode code points |
| 16 | 4 | float32 | logistic-regression intercept |

Current release values:

- entry count: `80000`
- max code points: `192`
- intercept: approximately `-2.8560934`

Header size is exactly `20` bytes.

## Entry records

Immediately after the header are exactly `entry_count` records. Records are variable length and appear in the original vectorizer feature-index order.

Each record is:

| Size | Type | Meaning |
|---:|---|---|
| 2 | uint16 | UTF-8 byte length `N` of the n-gram token |
| N | bytes | UTF-8 token bytes |
| 4 | float32 | IDF value |
| 4 | float32 | logistic-regression coefficient |

There is no alignment padding between records and no footer.

Pseudo-parser:

```text
magic      = readBytes(8)
entryCount = readUint32LE()
maxChars   = readUint32LE()
intercept  = readFloat32LE()

repeat entryCount times:
    n       = readUint16LE()
    token   = utf8Decode(readBytes(n))
    idf     = readFloat32LE()
    coef    = readFloat32LE()
```

A robust parser must reject a wrong magic, premature end-of-file, impossible lengths, or a final cursor that does not equal the file length.

## Feature semantics

The source vectorizer is equivalent to:

```text
analyzer = character
ngram_range = 2..5
sublinear_tf = true
norm = L2
lowercase = true
```

For a matched feature with occurrence count `c`:

```text
tf = 1 + ln(c)
value = tf * idf
```

Then normalize the sparse vector:

```text
norm = sqrt(sum(value_i ^ 2))
normalized_i = value_i / norm
```

Classifier:

```text
logit = intercept + sum(normalized_i * coefficient_i)
probability = sigmoid(logit)
```

If no vocabulary feature matches, `logit = intercept`.

## Preprocessing semantics

Before n-gram extraction:

1. truncate to the first 192 Unicode code points;
2. Unicode lowercase;
3. collapse any run matching Python `\s\s+` to one ASCII space;
4. perform no other normalization.

See `EXPO_MIGRATION.md` for JavaScript/TypeScript Unicode requirements.

## Current release integrity

- file: `tfidf_opening_192_plus_nlpcc.taid`
- size: `1,464,732` bytes
- SHA256: `9a504fb699d335836737a54fbdd839f3c9d2e3d48c0c2fc3dec2ff300ccc4300`

A fresh export from the frozen source sklearn pipeline was validated byte-for-byte identical to this artifact on 2026-09-03.
